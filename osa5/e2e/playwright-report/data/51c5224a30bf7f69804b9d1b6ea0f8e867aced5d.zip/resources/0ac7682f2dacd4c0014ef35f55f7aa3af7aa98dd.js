import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blogform.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b1a7c0cc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b1a7c0cc"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({ createBlog }) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    createBlog({ title, author, url });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create new blog" }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "title",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "Title",
            "data-testid": "title",
            value: title,
            onChange: ({ target }) => setTitle(target.value)
          },
          void 0,
          false,
          {
            fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
            lineNumber: 43,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "author",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            name: "Author",
            "data-testid": "author",
            value: author,
            onChange: ({ target }) => setAuthor(target.value)
          },
          void 0,
          false,
          {
            fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
            lineNumber: 53,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "url",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "url",
            name: "Url",
            "data-testid": "url",
            value: url,
            onChange: ({ target }) => setUrl(target.value)
          },
          void 0,
          false,
          {
            fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
            lineNumber: 63,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
        lineNumber: 71,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blogform.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxXQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUwsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ00sUUFBUUMsU0FBUyxJQUFJUCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDUSxLQUFLQyxNQUFNLElBQUlULFNBQVMsRUFBRTtBQUVqQyxRQUFNVSxlQUFlQSxDQUFDQyxVQUFVO0FBQzlCQSxVQUFNQyxlQUFlO0FBQ3JCVixlQUFXLEVBQUVFLE9BQU9FLFFBQVFFLElBQUksQ0FBQztBQUNqQ0gsYUFBUyxFQUFFO0FBQ1hFLGNBQVUsRUFBRTtBQUNaRSxXQUFPLEVBQUU7QUFBQSxFQUNYO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CO0FBQUEsSUFDbkIsdUJBQUMsVUFBSyxVQUFVQyxjQUNkO0FBQUEsNkJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsZUFBWTtBQUFBLFlBQ1osT0FBT047QUFBQUEsWUFDUCxVQUFVLENBQUMsRUFBRVMsT0FBTyxNQUFNUixTQUFTUSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxVQUxqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLbUQ7QUFBQSxXQVByRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE1BQUs7QUFBQSxZQUNMLGVBQVk7QUFBQSxZQUNaLE9BQU9SO0FBQUFBLFlBQ1AsVUFBVSxDQUFDLEVBQUVPLE9BQU8sTUFBTU4sVUFBVU0sT0FBT0MsS0FBSztBQUFBO0FBQUEsVUFMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS29EO0FBQUEsV0FQdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxlQUFZO0FBQUEsWUFDWixPQUFPTjtBQUFBQSxZQUNQLFVBQVUsQ0FBQyxFQUFFSyxPQUFPLE1BQU1KLE9BQU9JLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFVBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtpRDtBQUFBLFdBUG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQS9COUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdDQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDWCxHQW5ES0YsVUFBUTtBQUFBYyxLQUFSZDtBQXFETixlQUFlQTtBQUFRLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJsb2dGb3JtIiwiY3JlYXRlQmxvZyIsIl9zIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsImhhbmRsZVN1Ym1pdCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZ2Zvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIHJlYWN0L3Byb3AtdHlwZXMgKi9cblxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZ0Zvcm0gPSAoeyBjcmVhdGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2F1dGhvciwgc2V0QXV0aG9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNyZWF0ZUJsb2coeyB0aXRsZSwgYXV0aG9yLCB1cmwgfSlcbiAgICBzZXRUaXRsZSgnJylcbiAgICBzZXRBdXRob3IoJycpXG4gICAgc2V0VXJsKCcnKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkNyZWF0ZSBuZXcgYmxvZzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB0aXRsZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgbmFtZT1cIlRpdGxlXCJcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidGl0bGVcIlxuICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRUaXRsZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIGF1dGhvclxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgbmFtZT1cIkF1dGhvclwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cImF1dGhvclwiXG4gICAgICAgICAgICB2YWx1ZT17YXV0aG9yfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB1cmxcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ1cmxcIlxuICAgICAgICAgICAgbmFtZT1cIlVybFwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cInVybFwiXG4gICAgICAgICAgICB2YWx1ZT17dXJsfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVcmwodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+Y3JlYXRlPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6Ii9ob21lL2xhc3NpZS9NeVRlbXAva3Vyc3NpdC9mdWxsc3RhY2tfb3Blbi9mdWxsc3RhY2stb3Blbi9vc2E1L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dmb3JtLmpzeCJ9