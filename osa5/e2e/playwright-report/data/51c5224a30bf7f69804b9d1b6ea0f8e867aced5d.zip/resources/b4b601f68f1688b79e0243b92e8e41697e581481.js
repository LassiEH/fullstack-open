import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b1a7c0cc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=bf72a9ee"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const Notification = ({ notification }) => {
  if (notification === null) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "notification", children: notification.message }, void 0, false, {
    fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Notification.jsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
};
_c = Notification;
Notification.propTypes = {
  notification: PropTypes.shape({
    message: PropTypes.string.isRequired
  })
};
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSSixPQUFPQSxlQUFlO0FBRXRCLE1BQU1DLGVBQWVBLENBQUMsRUFBRUMsYUFBYSxNQUFNO0FBQ3pDLE1BQUlBLGlCQUFpQixNQUFNO0FBQ3pCLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVcsZ0JBQ2JBLHVCQUFhQyxXQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDQyxLQVZLSDtBQVlOQSxhQUFhSSxZQUFZO0FBQUEsRUFDdkJILGNBQWNGLFVBQVVNLE1BQU07QUFBQSxJQUM1QkgsU0FBU0gsVUFBVU8sT0FBT0M7QUFBQUEsRUFDNUIsQ0FBQztBQUNIO0FBR0EsZUFBZVA7QUFBWSxJQUFBRztBQUFBSyxhQUFBTCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwiTm90aWZpY2F0aW9uIiwibm90aWZpY2F0aW9uIiwibWVzc2FnZSIsIl9jIiwicHJvcFR5cGVzIiwic2hhcGUiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG5vdGlmaWNhdGlvbiB9KSA9PiB7XG4gIGlmIChub3RpZmljYXRpb24gPT09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17J25vdGlmaWNhdGlvbid9PlxuICAgICAge25vdGlmaWNhdGlvbi5tZXNzYWdlfVxuICAgIDwvZGl2PlxuICApXG59XG5cbk5vdGlmaWNhdGlvbi5wcm9wVHlwZXMgPSB7XG4gIG5vdGlmaWNhdGlvbjogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICBtZXNzYWdlOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIH0pLFxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbiJdLCJmaWxlIjoiL2hvbWUvbGFzc2llL015VGVtcC9rdXJzc2l0L2Z1bGxzdGFja19vcGVuL2Z1bGxzdGFjay1vcGVuL29zYTUvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9