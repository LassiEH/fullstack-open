import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b1a7c0cc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b1a7c0cc"; const useState = __vite__cjsImport3_react["useState"]; const forwardRef = __vite__cjsImport3_react["forwardRef"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=bf72a9ee"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = _s(forwardRef(_c = _s((props, refs) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = { display: visible ? "none" : "" };
  const showWhenVisible = { display: visible ? "" : "none" };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(refs, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
Togglable.propTypes = {
  buttonLabel: PropTypes.string.isRequired
};
Togglable.displayName = "Togglable";
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Togglable.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCUixTQUFTQSxVQUFVQyxZQUFZQywyQkFBMkI7QUFDMUQsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxZQUFTQyxHQUFHSixXQUFVSyxLQUFBRCxHQUFDLENBQUNFLE9BQU9DLFNBQVM7QUFBQUgsS0FBQTtBQUM1QyxRQUFNLENBQUNJLFNBQVNDLFVBQVUsSUFBSVYsU0FBUyxLQUFLO0FBRTVDLFFBQU1XLGtCQUFrQixFQUFFQyxTQUFTSCxVQUFVLFNBQVMsR0FBRztBQUN6RCxRQUFNSSxrQkFBa0IsRUFBRUQsU0FBU0gsVUFBVSxLQUFLLE9BQU87QUFFekQsUUFBTUssbUJBQW1CQSxNQUFNO0FBQzdCSixlQUFXLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUVBUCxzQkFBb0JNLE1BQU0sTUFBTTtBQUM5QixXQUFPO0FBQUEsTUFDTE07QUFBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksT0FBT0gsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTRyxrQkFBbUJQLGdCQUFNUSxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPRixpQkFDVE47QUFBQUEsWUFBTVM7QUFBQUEsTUFDUCx1QkFBQyxZQUFPLFNBQVNGLGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUosR0FBQyxrQ0FBQztBQUFBRyxNQTVCSWI7QUE4Qk5BLFVBQVVjLFlBQVk7QUFBQSxFQUNwQkgsYUFBYVosVUFBVWdCLE9BQU9DO0FBQ2hDO0FBRUFoQixVQUFVaUIsY0FBYztBQUV4QixlQUFlakI7QUFBUyxJQUFBRSxJQUFBVztBQUFBSyxhQUFBaEIsSUFBQTtBQUFBZ0IsYUFBQUwsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiZm9yd2FyZFJlZiIsInVzZUltcGVyYXRpdmVIYW5kbGUiLCJQcm9wVHlwZXMiLCJUb2dnbGFibGUiLCJfcyIsIl9jIiwicHJvcHMiLCJyZWZzIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImJ1dHRvbkxhYmVsIiwiY2hpbGRyZW4iLCJfYzIiLCJwcm9wVHlwZXMiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiZGlzcGxheU5hbWUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2dnbGFibGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIHJlYWN0L3Byb3AtdHlwZXMgKi9cblxuaW1wb3J0IHsgdXNlU3RhdGUsIGZvcndhcmRSZWYsIHVzZUltcGVyYXRpdmVIYW5kbGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgVG9nZ2xhYmxlID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZnMpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XG5cbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxuICB9XG5cbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZShyZWZzLCAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvZ2dsZVZpc2liaWxpdHksXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgc3R5bGU9e2hpZGVXaGVuVmlzaWJsZX0+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+e3Byb3BzLmJ1dHRvbkxhYmVsfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0+XG4gICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59KVxuXG5Ub2dnbGFibGUucHJvcFR5cGVzID0ge1xuICBidXR0b25MYWJlbDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxufVxuXG5Ub2dnbGFibGUuZGlzcGxheU5hbWUgPSAnVG9nZ2xhYmxlJ1xuXG5leHBvcnQgZGVmYXVsdCBUb2dnbGFibGUiXSwiZmlsZSI6Ii9ob21lL2xhc3NpZS9NeVRlbXAva3Vyc3NpdC9mdWxsc3RhY2tfb3Blbi9mdWxsc3RhY2stb3Blbi9vc2E1L2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1RvZ2dsYWJsZS5qc3gifQ==