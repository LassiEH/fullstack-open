import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b1a7c0cc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b1a7c0cc"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=bf72a9ee"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Blog = ({ username, blog, updateLikes, deleteBlog }) => {
  _s();
  const [detailsVisible, setDetailsVisible] = useState(false);
  Blog.propTypes = {
    username: PropTypes.string.isRequired,
    blog: PropTypes.object.isRequired,
    updateLikes: PropTypes.func.isRequired,
    deleteBlog: PropTypes.func.isRequired
  };
  const toggleDetails = () => {
    setDetailsVisible(!detailsVisible);
  };
  const handleLike = async () => {
    const blogToUpdate = {
      ...blog,
      user: blog.user.id || blog.user,
      likes: blog.likes + 1
    };
    const updatedBlog = await updateLikes(blogToUpdate);
  };
  const handleDelete = async () => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}`)) {
      deleteBlog(blog.id);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blogItem", "data-testid": "blogItem", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: [
        blog.title,
        " "
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: [
        blog.author,
        " "
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleDetails, children: detailsVisible ? "hide" : "view" }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 60,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    detailsVisible && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("a", { href: blog.url, children: blog.url }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "likes ",
          blog.likes
        ] }, void 0, true, {
          fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
          lineNumber: 70,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, children: "like" }, void 0, false, {
          fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
          lineNumber: 71,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 69,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: blog.user.name }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 74,
        columnNumber: 11
      }, this),
      blog.user.username === username && /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: handleDelete, children: "remove" }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 78,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
        lineNumber: 77,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
      lineNumber: 66,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
};
_s(Blog, "Hh5inoR7FNss1DRgdhm4+KI+HsY=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRDUixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxPQUFPQSxDQUFDLEVBQUVDLFVBQVVDLE1BQU1DLGFBQWFDLFdBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQzVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSVQsU0FBUyxLQUFLO0FBRTFERSxPQUFLUSxZQUFZO0FBQUEsSUFDakJQLFVBQVVGLFVBQVVVLE9BQU9DO0FBQUFBLElBQzNCUixNQUFNSCxVQUFVWSxPQUFPRDtBQUFBQSxJQUN2QlAsYUFBYUosVUFBVWEsS0FBS0Y7QUFBQUEsSUFDNUJOLFlBQVlMLFVBQVVhLEtBQUtGO0FBQUFBLEVBQzdCO0FBR0UsUUFBTUcsZ0JBQWdCQSxNQUFNO0FBQzFCTixzQkFBa0IsQ0FBQ0QsY0FBYztBQUFBLEVBQ25DO0FBRUEsUUFBTVEsYUFBYSxZQUFZO0FBQzdCLFVBQU1DLGVBQWU7QUFBQSxNQUNuQixHQUFHYjtBQUFBQSxNQUNIYyxNQUFNZCxLQUFLYyxLQUFLQyxNQUFNZixLQUFLYztBQUFBQSxNQUMzQkUsT0FBT2hCLEtBQUtnQixRQUFRO0FBQUEsSUFDdEI7QUFDQSxVQUFNQyxjQUFjLE1BQU1oQixZQUFZWSxZQUFZO0FBQUEsRUFHcEQ7QUFFQSxRQUFNSyxlQUFlLFlBQVk7QUFDL0IsUUFBSUMsT0FBT0MsUUFBUSxlQUFlcEIsS0FBS3FCLEtBQUssT0FBT3JCLEtBQUtzQixNQUFNLEVBQUUsR0FBRztBQUNqRXBCLGlCQUFXRixLQUFLZSxFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsWUFBVyxlQUFZLFlBQ3BDO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQU1mO0FBQUFBLGFBQUtxQjtBQUFBQSxRQUFNO0FBQUEsV0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLE1BQ25CLHVCQUFDLFVBQU1yQjtBQUFBQSxhQUFLc0I7QUFBQUEsUUFBTztBQUFBLFdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxNQUNwQix1QkFBQyxZQUFPLFNBQVNYLGVBQ2RQLDJCQUFpQixTQUFTLFVBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQ0Esa0JBQ0MsdUJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsTUFBTUosS0FBS3VCLEtBQU12QixlQUFLdUIsT0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BRTdCLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFPdkIsS0FBS2dCO0FBQUFBLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUN4Qix1QkFBQyxZQUFPLFNBQVNKLFlBQVksb0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxXQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFVBQU1aLGVBQUtjLEtBQUtVLFFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxNQUVyQnhCLEtBQUtjLEtBQUtmLGFBQWFBLFlBQ3RCLHVCQUFDLFNBQ0MsaUNBQUMsWUFBTyxTQUFTbUIsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLE9BekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkE7QUFFSjtBQUFDZixHQTlES0wsTUFBSTtBQUFBMkIsS0FBSjNCO0FBZ0VOLGVBQWVBO0FBQUksSUFBQTJCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsIkJsb2ciLCJ1c2VybmFtZSIsImJsb2ciLCJ1cGRhdGVMaWtlcyIsImRlbGV0ZUJsb2ciLCJfcyIsImRldGFpbHNWaXNpYmxlIiwic2V0RGV0YWlsc1Zpc2libGUiLCJwcm9wVHlwZXMiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwib2JqZWN0IiwiZnVuYyIsInRvZ2dsZURldGFpbHMiLCJoYW5kbGVMaWtlIiwiYmxvZ1RvVXBkYXRlIiwidXNlciIsImlkIiwibGlrZXMiLCJ1cGRhdGVkQmxvZyIsImhhbmRsZURlbGV0ZSIsIndpbmRvdyIsImNvbmZpcm0iLCJ0aXRsZSIsImF1dGhvciIsInVybCIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IEJsb2cgPSAoeyB1c2VybmFtZSwgYmxvZywgdXBkYXRlTGlrZXMsIGRlbGV0ZUJsb2cgfSkgPT4ge1xuICBjb25zdCBbZGV0YWlsc1Zpc2libGUsIHNldERldGFpbHNWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIEJsb2cucHJvcFR5cGVzID0ge1xuICB1c2VybmFtZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICBibG9nOiBQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWQsXG4gIHVwZGF0ZUxpa2VzOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBkZWxldGVCbG9nOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxufVxuXG5cbiAgY29uc3QgdG9nZ2xlRGV0YWlscyA9ICgpID0+IHtcbiAgICBzZXREZXRhaWxzVmlzaWJsZSghZGV0YWlsc1Zpc2libGUpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMaWtlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGJsb2dUb1VwZGF0ZSA9IHtcbiAgICAgIC4uLmJsb2csXG4gICAgICB1c2VyOiBibG9nLnVzZXIuaWQgfHwgYmxvZy51c2VyLFxuICAgICAgbGlrZXM6IGJsb2cubGlrZXMgKyAxLFxuICAgIH1cbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IHVwZGF0ZUxpa2VzKGJsb2dUb1VwZGF0ZSlcblxuICAgIC8vdXBkYXRlZEJsb2cudXNlciA9IGJsb2cudXNlclxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVtb3ZlIGJsb2cgJHtibG9nLnRpdGxlfSBieSAke2Jsb2cuYXV0aG9yfWApKSB7XG4gICAgICBkZWxldGVCbG9nKGJsb2cuaWQpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2dJdGVtXCIgZGF0YS10ZXN0aWQ9XCJibG9nSXRlbVwiPlxuICAgICAgPGRpdj5cbiAgICAgICAgPHNwYW4+e2Jsb2cudGl0bGV9IDwvc3Bhbj5cbiAgICAgICAgPHNwYW4+e2Jsb2cuYXV0aG9yfSA8L3NwYW4+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlRGV0YWlsc30+XG4gICAgICAgICAge2RldGFpbHNWaXNpYmxlID8gJ2hpZGUnIDogJ3ZpZXcnfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZGV0YWlsc1Zpc2libGUgJiYgKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxhIGhyZWY9e2Jsb2cudXJsfT57YmxvZy51cmx9PC9hPlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuPmxpa2VzIHtibG9nLmxpa2VzfTwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTGlrZX0+bGlrZTwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPHNwYW4+e2Jsb2cudXNlci5uYW1lfTwvc3Bhbj5cblxuICAgICAgICAgIHtibG9nLnVzZXIudXNlcm5hbWUgPT09IHVzZXJuYW1lICYmIChcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlRGVsZXRlfT5yZW1vdmU8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiIvaG9tZS9sYXNzaWUvTXlUZW1wL2t1cnNzaXQvZnVsbHN0YWNrX29wZW4vZnVsbHN0YWNrLW9wZW4vb3NhNS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9