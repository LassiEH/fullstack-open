import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Loginform.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b1a7c0cc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b1a7c0cc"; const useState = __vite__cjsImport3_react["useState"];
const Loginform = ({ handleLogin }) => {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    handleLogin(username, password);
    setUsername("");
    setPassword("");
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "username",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: username,
          "data-testid": "username",
          name: "Username",
          onChange: ({ target }) => setUsername(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx",
          lineNumber: 39,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx",
      lineNumber: 37,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "password",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          "data-testid": "password",
          name: "password",
          onChange: ({ target }) => setPassword(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx",
          lineNumber: 49,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx",
      lineNumber: 47,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx",
      lineNumber: 57,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_s(Loginform, "wuQOK7xaXdVz4RMrZQhWbI751Oc=");
_c = Loginform;
export default Loginform;
var _c;
$RefreshReg$(_c, "Loginform");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/components/Loginform.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqQmhCLFNBQVNBLGdCQUFnQjtBQUV6QixNQUFNQyxZQUFZQSxDQUFDLEVBQUVDLFlBQVksTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJTCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDTSxVQUFVQyxXQUFXLElBQUlQLFNBQVMsRUFBRTtBQUUzQyxRQUFNUSxlQUFlQSxDQUFDQyxVQUFVO0FBQzVCQSxVQUFNQyxlQUFlO0FBQ3JCUixnQkFBWUUsVUFBVUUsUUFBUTtBQUM5QkQsZ0JBQVksRUFBRTtBQUNkRSxnQkFBWSxFQUFFO0FBQUEsRUFDbEI7QUFFQSxTQUNJLHVCQUFDLFVBQUssVUFBVUMsY0FDWjtBQUFBLDJCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNELE1BQUs7QUFBQSxVQUNMLE9BQU9KO0FBQUFBLFVBQ1AsZUFBWTtBQUFBLFVBQ1osTUFBSztBQUFBLFVBQ0wsVUFBVSxDQUFDLEVBQUVPLE9BQU8sTUFBTU4sWUFBWU0sT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS29EO0FBQUEsU0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRCxNQUFLO0FBQUEsVUFDTCxPQUFPTjtBQUFBQSxVQUNQLGVBQVk7QUFBQSxVQUNaLE1BQUs7QUFBQSxVQUNMLFVBQVUsQ0FBQyxFQUFFSyxPQUFPLE1BQU1KLFlBQVlJLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtvRDtBQUFBLFNBUHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxPQXJCL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVSO0FBQUNULEdBcENLRixXQUFTO0FBQUFZLEtBQVRaO0FBc0NOLGVBQWVBO0FBQVMsSUFBQVk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTG9naW5mb3JtIiwiaGFuZGxlTG9naW4iLCJfcyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2dpbmZvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIHJlYWN0L3Byb3AtdHlwZXMgKi9cblxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgTG9naW5mb3JtID0gKHsgaGFuZGxlTG9naW4gfSkgPT4ge1xuICAgIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChldmVudCkgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIGhhbmRsZUxvZ2luKHVzZXJuYW1lLCBwYXNzd29yZClcbiAgICAgICAgc2V0VXNlcm5hbWUoJycpXG4gICAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH1cblxuICAgIHJldHVybiAoXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgICBuYW1lPSdVc2VybmFtZSdcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgcGFzc3dvcmRcbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBuYW1lPSdwYXNzd29yZCdcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9J3N1Ym1pdCc+bG9naW48L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTG9naW5mb3JtXG5cbiJdLCJmaWxlIjoiL2hvbWUvbGFzc2llL015VGVtcC9rdXJzc2l0L2Z1bGxzdGFja19vcGVuL2Z1bGxzdGFjay1vcGVuL29zYTUvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5mb3JtLmpzeCJ9