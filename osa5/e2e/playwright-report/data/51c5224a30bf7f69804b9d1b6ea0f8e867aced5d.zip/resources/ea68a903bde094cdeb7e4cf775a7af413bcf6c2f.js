import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/index.css"
const __vite__css = ".notification {\n  background: grey;\n  border-radius: 5px;\n  padding: 10px;\n  font-size: 30px;\n  padding: 10px;\n  margin-bottom: 10px;\n}\n\n.blogItem {\n  padding-top: 10px;\n  border: solid;\n  border-width: 0.5px;\n  margin-bottom: 10px;\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))