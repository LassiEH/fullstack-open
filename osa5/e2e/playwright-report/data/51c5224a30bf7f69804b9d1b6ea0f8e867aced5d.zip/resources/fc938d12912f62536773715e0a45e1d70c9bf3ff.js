import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b1a7c0cc"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b1a7c0cc"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1757108793794";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import Notification from "/src/components/Notification.jsx?t=1756928362088";
import Loginform from "/src/components/Loginform.jsx?t=1756844360811";
import Blogform from "/src/components/Blogform.jsx?t=1756926644033";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [notification, setNotification] = useState(null);
  const [user, setUser] = useState(null);
  const blogFormRef = useRef();
  useEffect(() => {
    blogService.getAll().then(
      (blogs2) => setBlogs(blogs2)
    );
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleNotification = (message) => {
    setNotification({ message });
    setTimeout(() => {
      setNotification(null);
    }, 4e3);
  };
  const handleError = (error) => {
    if (error.response.data.error) {
      handleNotification(error.response.data.error);
    } else {
      handleNotification("unknown error");
    }
  };
  const handleLogin = async (username, password) => {
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem(
        "loggedBlogappUser",
        JSON.stringify(user2)
      );
      blogService.setToken(user2.token);
      setUser(user2);
      handleNotification(`Welcome ${user2.username}`);
    } catch (error) {
      handleError(error);
    }
    console.log("logging in with", username, password);
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    setUser(null);
    blogService.setToken(null);
  };
  const createBlog = async (blogObject) => {
    try {
      blogFormRef.current.toggleVisibility();
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(returnedBlog));
      handleNotification(`${returnedBlog.title} by ${returnedBlog.author} added`);
    } catch (error) {
      handleError(`Error: ${error.response.data.error}`);
    }
  };
  const deleteBlog = async (blogId) => {
    try {
      await blogService.deleteBlog(blogId);
      const newBlogs = blogs.filter((blog) => blog.id !== blogId);
      setBlogs(newBlogs);
      handleNotification("Blog deleted");
    } catch (error) {
      handleError(`Error: ${error.response.data.error}`);
    }
  };
  const updateBlog = async (blogObject) => {
    try {
      const updatedBlog = await blogService.update(blogObject.id, blogObject);
      if (typeof updatedBlog.user === "string") {
        const original = blogs.find((b) => b.id === blogObject.id);
        updatedBlog.user = original.user;
      }
      setBlogs(blogs.map((b) => b.id === updatedBlog.id ? updatedBlog : b));
      handleNotification("Updated blogs");
      return updatedBlog;
    } catch (error) {
      handleError(`Error: ${error.response.data.error}`);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
      lineNumber: 132,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { notification }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
      lineNumber: 134,
      columnNumber: 7
    }, this),
    user === null ? /* @__PURE__ */ jsxDEV(Loginform, { handleLogin }, void 0, false, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
      lineNumber: 136,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        user.name,
        " logged in",
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleLogout, children: "logout" }, void 0, false, {
          fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
          lineNumber: 141,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
        lineNumber: 139,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(Blogform, { createBlog }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
        lineNumber: 146,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      blogs.sort((a, b) => b.likes - a.likes).map(
        (blog) => /* @__PURE__ */ jsxDEV(
          Blog,
          {
            blog,
            username: user.username,
            deleteBlog,
            updateLikes: updateBlog
          },
          blog.id,
          false,
          {
            fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
            lineNumber: 151,
            columnNumber: 9
          },
          this
        )
      )
    ] }, void 0, true, {
      fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
      lineNumber: 138,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx",
    lineNumber: 131,
    columnNumber: 5
  }, this);
};
_s(App, "XRTnLYMQmpq506LzIj7Of59pgUw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/lassie/MyTemp/kurssit/fullstack_open/fullstack-open/osa5/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0hNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhITixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFFdEIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYyxjQUFjQyxlQUFlLElBQUlmLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNnQixNQUFNQyxPQUFPLElBQUlqQixTQUFTLElBQUk7QUFFckMsUUFBTWtCLGNBQWNoQixPQUFPO0FBRTNCRCxZQUFVLE1BQU07QUFDZEcsZ0JBQVllLE9BQU8sRUFBRUM7QUFBQUEsTUFBSyxDQUFBUixXQUN4QkMsU0FBVUQsTUFBTTtBQUFBLElBQ2xCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTFgsWUFBVSxNQUFNO0FBQ2QsVUFBTW9CLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxtQkFBbUI7QUFDdEUsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1MLFFBQU9TLEtBQUtDLE1BQU1MLGNBQWM7QUFDdENKLGNBQVFELEtBQUk7QUFDWlosa0JBQVl1QixTQUFTWCxNQUFLWSxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLHFCQUFxQkEsQ0FBQ0MsWUFBWTtBQUN0Q2Ysb0JBQWdCLEVBQUVlLFFBQVEsQ0FBQztBQUMzQkMsZUFBVyxNQUFNO0FBQ2ZoQixzQkFBZ0IsSUFBSTtBQUFBLElBQ3RCLEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUFFQSxRQUFNaUIsY0FBY0EsQ0FBQ0MsVUFBVTtBQUM3QixRQUFJQSxNQUFNQyxTQUFTQyxLQUFLRixPQUFPO0FBQzdCSix5QkFBbUJJLE1BQU1DLFNBQVNDLEtBQUtGLEtBQUs7QUFBQSxJQUM5QyxPQUFPO0FBQ0xKLHlCQUFtQixlQUFlO0FBQUEsSUFDcEM7QUFBQSxFQUNGO0FBRUEsUUFBTU8sY0FBYyxPQUFPQyxVQUFVQyxhQUFhO0FBQ2hELFFBQUk7QUFDRixZQUFNdEIsUUFBTyxNQUFNWCxhQUFha0MsTUFBTTtBQUFBLFFBQ3BDRjtBQUFBQSxRQUFVQztBQUFBQSxNQUNaLENBQUM7QUFFRGhCLGFBQU9DLGFBQWFpQjtBQUFBQSxRQUNsQjtBQUFBLFFBQXFCZixLQUFLZ0IsVUFBVXpCLEtBQUk7QUFBQSxNQUMxQztBQUNBWixrQkFBWXVCLFNBQVNYLE1BQUtZLEtBQUs7QUFDL0JYLGNBQVFELEtBQUk7QUFDWmEseUJBQW1CLFdBQVdiLE1BQUtxQixRQUFRLEVBQUU7QUFBQSxJQUMvQyxTQUFTSixPQUFPO0FBQ2RELGtCQUFZQyxLQUFLO0FBQUEsSUFDbkI7QUFFQVMsWUFBUUMsSUFBSSxtQkFBbUJOLFVBQVVDLFFBQVE7QUFBQSxFQUNuRDtBQUVBLFFBQU1NLGVBQWVBLE1BQU07QUFDekJ0QixXQUFPQyxhQUFhc0IsV0FBVyxtQkFBbUI7QUFDbEQ1QixZQUFRLElBQUk7QUFDWmIsZ0JBQVl1QixTQUFTLElBQUk7QUFBQSxFQUMzQjtBQUVBLFFBQU1tQixhQUFhLE9BQU9DLGVBQWU7QUFDdkMsUUFBSTtBQUNGN0Isa0JBQVk4QixRQUFRQyxpQkFBaUI7QUFDckMsWUFBTUMsZUFBZSxNQUFNOUMsWUFBWStDLE9BQU9KLFVBQVU7QUFDeERsQyxlQUFTRCxNQUFNd0MsT0FBT0YsWUFBWSxDQUFDO0FBQ25DckIseUJBQW1CLEdBQUdxQixhQUFhRyxLQUFLLE9BQU9ILGFBQWFJLE1BQU0sUUFBUTtBQUFBLElBQzVFLFNBQVNyQixPQUFPO0FBQ2RELGtCQUFZLFVBQVVDLE1BQU1DLFNBQVNDLEtBQUtGLEtBQUssRUFBRTtBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUVBLFFBQU1zQixhQUFhLE9BQU9DLFdBQVc7QUFDbkMsUUFBSTtBQUNGLFlBQU1wRCxZQUFZbUQsV0FBV0MsTUFBTTtBQUNuQyxZQUFNQyxXQUFXN0MsTUFBTThDLE9BQU8sQ0FBQ0MsU0FBU0EsS0FBS0MsT0FBT0osTUFBTTtBQUMxRDNDLGVBQVM0QyxRQUFRO0FBQ2pCNUIseUJBQW1CLGNBQWM7QUFBQSxJQUNuQyxTQUFTSSxPQUFPO0FBQ2RELGtCQUFZLFVBQVVDLE1BQU1DLFNBQVNDLEtBQUtGLEtBQUssRUFBRTtBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUVBLFFBQU00QixhQUFhLE9BQU9kLGVBQWU7QUFDdkMsUUFBSTtBQUNKLFlBQU1lLGNBQWMsTUFBTTFELFlBQVkyRCxPQUFPaEIsV0FBV2EsSUFBSWIsVUFBVTtBQUV0RSxVQUFJLE9BQU9lLFlBQVk5QyxTQUFTLFVBQVU7QUFDeEMsY0FBTWdELFdBQVdwRCxNQUFNcUQsS0FBSyxDQUFBQyxNQUFLQSxFQUFFTixPQUFPYixXQUFXYSxFQUFFO0FBQ3ZERSxvQkFBWTlDLE9BQU9nRCxTQUFTaEQ7QUFBQUEsTUFDOUI7QUFFQUgsZUFBU0QsTUFBTXVELElBQUksQ0FBQUQsTUFBS0EsRUFBRU4sT0FBT0UsWUFBWUYsS0FBS0UsY0FBY0ksQ0FBQyxDQUFDO0FBQ2xFckMseUJBQW1CLGVBQWU7QUFDbEMsYUFBT2lDO0FBQUFBLElBQ1QsU0FBUzdCLE9BQU87QUFDZEQsa0JBQVksVUFBVUMsTUFBTUMsU0FBU0MsS0FBS0YsS0FBSyxFQUFFO0FBQUEsSUFDbkQ7QUFBQSxFQUNGO0FBRUUsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUVULHVCQUFDLGdCQUFhLGdCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUN4Q2pCLFNBQVMsT0FDUix1QkFBQyxhQUFVLGVBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQyxJQUVwQyx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsT0FDRUE7QUFBQUEsYUFBS29EO0FBQUFBLFFBQUs7QUFBQSxRQUNYLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVN4QixjQUFhLHNCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsYUFBVSxhQUFZLG1CQUFrQixLQUFLMUIsYUFDNUMsaUNBQUMsWUFBUyxjQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUMsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ04sTUFDRXlELEtBQUssQ0FBQ0MsR0FBR0osTUFBTUEsRUFBRUssUUFBUUQsRUFBRUMsS0FBSyxFQUNoQ0o7QUFBQUEsUUFBSSxDQUFDUixTQUNKO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQztBQUFBLFlBQ0EsVUFBVTNDLEtBQUtxQjtBQUFBQSxZQUNmO0FBQUEsWUFDQSxhQUFhd0I7QUFBQUE7QUFBQUEsVUFKUkYsS0FBS0M7QUFBQUEsVUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSzBCO0FBQUEsTUFFM0I7QUFBQSxTQXBCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsT0E1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThCQTtBQUVKO0FBQUNqRCxHQXRJS0QsS0FBRztBQUFBOEQsS0FBSDlEO0FBd0lOLGVBQWVBO0FBQUcsSUFBQThEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkJsb2ciLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIk5vdGlmaWNhdGlvbiIsIkxvZ2luZm9ybSIsIkJsb2dmb3JtIiwiVG9nZ2xhYmxlIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwibm90aWZpY2F0aW9uIiwic2V0Tm90aWZpY2F0aW9uIiwidXNlciIsInNldFVzZXIiLCJibG9nRm9ybVJlZiIsImdldEFsbCIsInRoZW4iLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiaGFuZGxlTm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInNldFRpbWVvdXQiLCJoYW5kbGVFcnJvciIsImVycm9yIiwicmVzcG9uc2UiLCJkYXRhIiwiaGFuZGxlTG9naW4iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiY29uc29sZSIsImxvZyIsImhhbmRsZUxvZ291dCIsInJlbW92ZUl0ZW0iLCJjcmVhdGVCbG9nIiwiYmxvZ09iamVjdCIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicmV0dXJuZWRCbG9nIiwiY3JlYXRlIiwiY29uY2F0IiwidGl0bGUiLCJhdXRob3IiLCJkZWxldGVCbG9nIiwiYmxvZ0lkIiwibmV3QmxvZ3MiLCJmaWx0ZXIiLCJibG9nIiwiaWQiLCJ1cGRhdGVCbG9nIiwidXBkYXRlZEJsb2ciLCJ1cGRhdGUiLCJvcmlnaW5hbCIsImZpbmQiLCJiIiwibWFwIiwibmFtZSIsInNvcnQiLCJhIiwibGlrZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uJ1xuaW1wb3J0IExvZ2luZm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5mb3JtJ1xuaW1wb3J0IEJsb2dmb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nZm9ybSdcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcblxuICBjb25zdCBibG9nRm9ybVJlZiA9IHVzZVJlZigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XG4gICAgICBzZXRCbG9ncyggYmxvZ3MgKVxuICAgICkgIFxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfSAgXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGhhbmRsZU5vdGlmaWNhdGlvbiA9IChtZXNzYWdlKSA9PiB7XG4gICAgc2V0Tm90aWZpY2F0aW9uKHsgbWVzc2FnZSB9KVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0Tm90aWZpY2F0aW9uKG51bGwpXG4gICAgfSwgNDAwMClcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUVycm9yID0gKGVycm9yKSA9PiB7XG4gICAgaWYgKGVycm9yLnJlc3BvbnNlLmRhdGEuZXJyb3IpIHtcbiAgICAgIGhhbmRsZU5vdGlmaWNhdGlvbihlcnJvci5yZXNwb25zZS5kYXRhLmVycm9yKVxuICAgIH0gZWxzZSB7XG4gICAgICBoYW5kbGVOb3RpZmljYXRpb24oJ3Vua25vd24gZXJyb3InKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKHVzZXJuYW1lLCBwYXNzd29yZCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHtcbiAgICAgICAgdXNlcm5hbWUsIHBhc3N3b3JkXG4gICAgICB9KVxuXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICdsb2dnZWRCbG9nYXBwVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpXG4gICAgICApXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgaGFuZGxlTm90aWZpY2F0aW9uKGBXZWxjb21lICR7dXNlci51c2VybmFtZX1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBoYW5kbGVFcnJvcihlcnJvcilcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZygnbG9nZ2luZyBpbiB3aXRoJywgdXNlcm5hbWUsIHBhc3N3b3JkKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgICBibG9nU2VydmljZS5zZXRUb2tlbihudWxsKVxuICB9XG5cbiAgY29uc3QgY3JlYXRlQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGJsb2dGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdClcbiAgICAgIHNldEJsb2dzKGJsb2dzLmNvbmNhdChyZXR1cm5lZEJsb2cpKVxuICAgICAgaGFuZGxlTm90aWZpY2F0aW9uKGAke3JldHVybmVkQmxvZy50aXRsZX0gYnkgJHtyZXR1cm5lZEJsb2cuYXV0aG9yfSBhZGRlZGApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGhhbmRsZUVycm9yKGBFcnJvcjogJHtlcnJvci5yZXNwb25zZS5kYXRhLmVycm9yfWApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZGVsZXRlQmxvZyA9IGFzeW5jIChibG9nSWQpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhibG9nSWQpXG4gICAgICBjb25zdCBuZXdCbG9ncyA9IGJsb2dzLmZpbHRlcigoYmxvZykgPT4gYmxvZy5pZCAhPT0gYmxvZ0lkKVxuICAgICAgc2V0QmxvZ3MobmV3QmxvZ3MpXG4gICAgICBoYW5kbGVOb3RpZmljYXRpb24oJ0Jsb2cgZGVsZXRlZCcpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGhhbmRsZUVycm9yKGBFcnJvcjogJHtlcnJvci5yZXNwb25zZS5kYXRhLmVycm9yfWApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgdXBkYXRlQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZShibG9nT2JqZWN0LmlkLCBibG9nT2JqZWN0KVxuXG4gICAgaWYgKHR5cGVvZiB1cGRhdGVkQmxvZy51c2VyID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3Qgb3JpZ2luYWwgPSBibG9ncy5maW5kKGIgPT4gYi5pZCA9PT0gYmxvZ09iamVjdC5pZClcbiAgICAgIHVwZGF0ZWRCbG9nLnVzZXIgPSBvcmlnaW5hbC51c2VyXG4gICAgfVxuXG4gICAgc2V0QmxvZ3MoYmxvZ3MubWFwKGIgPT4gYi5pZCA9PT0gdXBkYXRlZEJsb2cuaWQgPyB1cGRhdGVkQmxvZyA6IGIpKVxuICAgIGhhbmRsZU5vdGlmaWNhdGlvbignVXBkYXRlZCBibG9ncycpXG4gICAgcmV0dXJuIHVwZGF0ZWRCbG9nXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgaGFuZGxlRXJyb3IoYEVycm9yOiAke2Vycm9yLnJlc3BvbnNlLmRhdGEuZXJyb3J9YClcbiAgfVxufVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5ibG9nczwvaDI+XG5cbiAgICAgIDxOb3RpZmljYXRpb24gbm90aWZpY2F0aW9uPXtub3RpZmljYXRpb259IC8+XG4gICAgICB7dXNlciA9PT0gbnVsbCA/IChcbiAgICAgICAgPExvZ2luZm9ybSBoYW5kbGVMb2dpbj17aGFuZGxlTG9naW59IC8+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAge3VzZXIubmFtZX0gbG9nZ2VkIGluXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PlxuICAgICAgICAgICAgICBsb2dvdXRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmVsPVwiY3JlYXRlIG5ldyBibG9nXCIgcmVmPXtibG9nRm9ybVJlZn0+XG4gICAgICAgICAgICA8QmxvZ2Zvcm0gY3JlYXRlQmxvZz17Y3JlYXRlQmxvZ30gLz5cbiAgICAgICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgICAgICB7YmxvZ3NcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcbiAgICAgICAgICAgIC5tYXAoKGJsb2cpID0+IChcbiAgICAgICAgICAgICAgPEJsb2dcbiAgICAgICAgICAgICAgICBrZXk9e2Jsb2cuaWR9XG4gICAgICAgICAgICAgICAgYmxvZz17YmxvZ31cbiAgICAgICAgICAgICAgICB1c2VybmFtZT17dXNlci51c2VybmFtZX1cbiAgICAgICAgICAgICAgICBkZWxldGVCbG9nPXtkZWxldGVCbG9nfVxuICAgICAgICAgICAgICAgIHVwZGF0ZUxpa2VzPXt1cGRhdGVCbG9nfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9ob21lL2xhc3NpZS9NeVRlbXAva3Vyc3NpdC9mdWxsc3RhY2tfb3Blbi9mdWxsc3RhY2stb3Blbi9vc2E1L2Zyb250ZW5kL3NyYy9BcHAuanN4In0=